import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // === Projects ===
  
  // List Projects
  app.get(api.projects.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const projects = await storage.getProjects(userId);
    res.json(projects);
  });

  // Create Project
  app.post(api.projects.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.projects.create.input.parse(req.body);
      // Ensure user owns the project
      const userId = req.user.claims.sub;
      
      const project = await storage.createProject({
        ...input,
        userId
      });
      
      // Seed some initial files for the project
      await storage.createFile({
        projectId: project.id,
        name: "index.js",
        content: `console.log("Hello, Tritec!");\n`
      });
      
      await storage.createFile({
        projectId: project.id,
        name: "README.md",
        content: `# ${project.name}\n\n${project.description || "A new project."}`
      });

      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Get Project
  app.get(api.projects.get.path, isAuthenticated, async (req: any, res) => {
    const project = await storage.getProject(Number(req.params.id));
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    
    // Check ownership
    if (project.userId !== req.user.claims.sub) {
       return res.status(404).json({ message: 'Project not found' }); // Hide existence
    }

    res.json(project);
  });

  // === Files ===

  // List Files
  app.get(api.files.list.path, isAuthenticated, async (req: any, res) => {
    const projectId = Number(req.params.projectId);
    
    // Check project ownership
    const project = await storage.getProject(projectId);
    if (!project || project.userId !== req.user.claims.sub) {
       return res.status(404).json({ message: 'Project not found' });
    }

    const files = await storage.getFiles(projectId);
    res.json(files);
  });

  // Create File
  app.post(api.files.create.path, isAuthenticated, async (req: any, res) => {
     try {
      const projectId = Number(req.params.projectId);
      // Check project ownership
      const project = await storage.getProject(projectId);
      if (!project || project.userId !== req.user.claims.sub) {
         return res.status(404).json({ message: 'Project not found' });
      }

      const input = api.files.create.input.parse(req.body);
      const file = await storage.createFile({
        projectId,
        name: input.name,
        content: input.content
      });
      res.status(201).json(file);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Update File
  app.put(api.files.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const id = Number(req.params.id);
      const input = api.files.update.input.parse(req.body);

      // We need to verify file ownership via project
      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      const project = await storage.getProject(file.projectId);
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "File not found" });
      }

      const updatedFile = await storage.updateFile(id, input.content);
      res.json(updatedFile);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Delete File
  app.delete(api.files.delete.path, isAuthenticated, async (req: any, res) => {
     const id = Number(req.params.id);
      // We need to verify file ownership via project
      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      const project = await storage.getProject(file.projectId);
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "File not found" });
      }
      
      await storage.deleteFile(id);
      res.sendStatus(204);
  });

  // === Execution ===
  app.post(api.execution.run.path, isAuthenticated, async (req: any, res) => {
    const { code, language } = req.body;
    
    // Mock execution
    let output = "";
    if (language === "javascript" || language === "js") {
       try {
         // VERY UNSAFE - DO NOT DO THIS IN PRODUCTION with real user input unless sandboxed
         // For this demo/mock, we'll just echo or simulate simple logging.
         // Actually running eval is dangerous. Let's just mock typical output.
         if (code.includes("console.log")) {
           const match = code.match(/console\.log\((.*)\)/);
           if (match) {
             const content = match[1].replace(/['"]/g, "");
             output = `${content}\n> Process exited with code 0`;
           } else {
             output = "> Process exited with code 0";
           }
         } else {
           output = "> Process exited with code 0";
         }
       } catch (e) {
         output = "Error executing code";
       }
    } else {
      output = `Execution for ${language} not supported in this mock.`;
    }

    res.json({ output });
  });

  return httpServer;
}
