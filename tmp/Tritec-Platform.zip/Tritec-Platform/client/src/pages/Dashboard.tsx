import { useProjects } from "@/hooks/use-projects";
import { Layout } from "@/components/Layout";
import { CreateProjectDialog } from "@/components/CreateProjectDialog";
import { Card, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Link } from "wouter";
import { Folder, Clock, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { data: projects, isLoading, error } = useProjects();

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Your Projects</h1>
            <p className="text-muted-foreground mt-1">Manage and create new development environments.</p>
          </div>
          <CreateProjectDialog />
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-12 bg-destructive/10 rounded-xl text-destructive">
            <p>Failed to load projects. Please try again.</p>
          </div>
        ) : projects?.length === 0 ? (
          <div className="text-center py-20 bg-card rounded-2xl border border-dashed border-border">
            <Folder className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-medium text-foreground">No projects yet</h3>
            <p className="text-muted-foreground mb-6">Create your first project to get started coding.</p>
            <CreateProjectDialog />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects?.map((project) => (
              <Link key={project.id} href={`/project/${project.id}`}>
                <div className="group cursor-pointer h-full">
                  <Card className="h-full bg-card hover:bg-secondary/50 border-border hover:border-primary/50 transition-all duration-200 hover:-translate-y-1">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <CardTitle className="text-xl group-hover:text-primary transition-colors">
                            {project.name}
                          </CardTitle>
                          <CardDescription className="line-clamp-2">
                            {project.description || "No description provided."}
                          </CardDescription>
                        </div>
                        <div className="p-2 bg-primary/10 rounded-md text-primary">
                          <Folder className="w-4 h-4" />
                        </div>
                      </div>
                    </CardHeader>
                    <CardFooter className="mt-auto pt-4 text-xs text-muted-foreground flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      Updated {project.createdAt ? formatDistanceToNow(new Date(project.createdAt), { addSuffix: true }) : 'recently'}
                    </CardFooter>
                  </Card>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
