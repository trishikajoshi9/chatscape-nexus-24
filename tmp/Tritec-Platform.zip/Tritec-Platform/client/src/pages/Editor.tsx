import { useParams, useLocation } from "wouter";
import { useProject, useRunCode } from "@/hooks/use-projects";
import { useFiles, useCreateFile, useUpdateFile, useDeleteFile } from "@/hooks/use-files";
import { useState, useEffect, useCallback } from "react";
import Editor from "@monaco-editor/react";
import { 
  Loader2, Play, FileCode, Plus, Save, Trash2, 
  ChevronLeft, LayoutPanelLeft, TerminalSquare 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { debounce } from "lodash";

export default function ProjectEditor() {
  const { id } = useParams();
  const projectId = Number(id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: project, isLoading: projectLoading } = useProject(projectId);
  const { data: files, isLoading: filesLoading } = useFiles(projectId);
  
  const { mutate: createFile } = useCreateFile();
  const { mutate: updateFile } = useUpdateFile();
  const { mutate: deleteFile } = useDeleteFile();
  const { mutate: runCode, isPending: isRunning } = useRunCode();

  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [output, setOutput] = useState<string>("");
  const [newFileName, setNewFileName] = useState("");
  const [isNewFileOpen, setIsNewFileOpen] = useState(false);

  // Set first file as active when loaded
  useEffect(() => {
    if (files && files.length > 0 && !activeFileId) {
      setActiveFileId(files[0].id);
    }
  }, [files, activeFileId]);

  const activeFile = files?.find(f => f.id === activeFileId);

  // Auto-save logic
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedSave = useCallback(
    debounce((fileId: number, content: string) => {
      updateFile({ id: fileId, projectId, content });
    }, 1000),
    [projectId, updateFile]
  );

  const handleEditorChange = (value: string | undefined) => {
    if (activeFileId && value !== undefined) {
      debouncedSave(activeFileId, value);
    }
  };

  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName) return;
    
    createFile({ projectId, name: newFileName, content: "// New file" }, {
      onSuccess: (file) => {
        setNewFileName("");
        setIsNewFileOpen(false);
        setActiveFileId(file.id);
        toast({ title: "File created" });
      }
    });
  };

  const handleDeleteFile = (e: React.MouseEvent, fileId: number) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this file?")) {
      deleteFile({ id: fileId, projectId }, {
        onSuccess: () => {
          if (activeFileId === fileId) setActiveFileId(null);
          toast({ title: "File deleted" });
        }
      });
    }
  };

  const handleRun = () => {
    if (!activeFile) return;
    
    // Simple language detection based on extension
    const ext = activeFile.name.split('.').pop() || 'js';
    const language = ext === 'py' ? 'python' : 'javascript';
    
    setOutput("Running...");
    runCode({ code: activeFile.content, language }, {
      onSuccess: (data) => {
        if (data.error) {
          setOutput(`Error:\n${data.error}`);
        } else {
          setOutput(data.output || "No output");
        }
      },
      onError: (err) => {
        setOutput(`Execution failed: ${err.message}`);
      }
    });
  };

  if (projectLoading || filesLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground animate-pulse">Loading environment...</p>
        </div>
      </div>
    );
  }

  if (!project) return <div>Project not found</div>;

  return (
    <div className="h-screen flex flex-col bg-background text-foreground overflow-hidden">
      {/* Top Bar */}
      <header className="h-12 border-b border-border bg-card flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
            <ChevronLeft className="w-5 h-5 text-muted-foreground" />
          </Button>
          <div className="flex flex-col">
            <span className="font-semibold text-sm leading-tight">{project.name}</span>
            <span className="text-[10px] text-muted-foreground">Edited just now</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button 
            onClick={handleRun} 
            disabled={isRunning || !activeFile}
            className="bg-green-600 hover:bg-green-700 text-white h-8 px-4 font-mono text-xs"
          >
            {isRunning ? <Loader2 className="w-3 h-3 mr-2 animate-spin" /> : <Play className="w-3 h-3 mr-2 fill-current" />}
            RUN
          </Button>
          <div className="w-px h-6 bg-border mx-1" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center text-xs font-bold border border-primary/30">
              ME
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          
          {/* Sidebar */}
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30} className="bg-card border-r border-border flex flex-col">
            <div className="p-3 border-b border-border flex items-center justify-between">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <LayoutPanelLeft className="w-3 h-3" /> Files
              </span>
              
              <Dialog open={isNewFileOpen} onOpenChange={setIsNewFileOpen}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <Plus className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New File</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateFile} className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="filename">Filename</Label>
                      <Input 
                        id="filename" 
                        placeholder="script.js" 
                        value={newFileName} 
                        onChange={e => setNewFileName(e.target.value)}
                        className="font-mono"
                      />
                    </div>
                    <DialogFooter>
                      <Button type="submit">Create</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            
            <ScrollArea className="flex-1">
              <div className="p-2 space-y-1">
                {files?.map(file => (
                  <div 
                    key={file.id}
                    onClick={() => setActiveFileId(file.id)}
                    className={`
                      group flex items-center justify-between px-3 py-2 rounded-md text-sm cursor-pointer transition-colors
                      ${activeFileId === file.id ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}
                    `}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileCode className="w-4 h-4 shrink-0" />
                      <span className="truncate">{file.name}</span>
                    </div>
                    <Button
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-destructive/20 hover:text-destructive"
                      onClick={(e) => handleDeleteFile(e, file.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </ResizablePanel>
          
          <ResizableHandle className="bg-border hover:bg-primary transition-colors w-[2px]" />
          
          {/* Editor & Terminal Group */}
          <ResizablePanel defaultSize={80}>
            <ResizablePanelGroup direction="vertical">
              
              {/* Code Editor */}
              <ResizablePanel defaultSize={70} className="relative bg-[#1e1e1e]">
                {activeFile ? (
                  <Editor
                    height="100%"
                    defaultLanguage="javascript"
                    language={
                      activeFile.name.endsWith('css') ? 'css' :
                      activeFile.name.endsWith('html') ? 'html' :
                      activeFile.name.endsWith('py') ? 'python' : 
                      activeFile.name.endsWith('json') ? 'json' :
                      'javascript'
                    }
                    path={activeFile.name} // Important for model switching
                    defaultValue={activeFile.content}
                    theme="vs-dark"
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                      fontFamily: "'JetBrains Mono', monospace",
                      lineHeight: 22,
                      scrollBeyondLastLine: false,
                      padding: { top: 16, bottom: 16 },
                      cursorBlinking: 'smooth',
                      smoothScrolling: true,
                    }}
                    onChange={handleEditorChange}
                    loading={<Loader2 className="w-8 h-8 animate-spin text-primary m-auto" />}
                  />
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                    <FileCode className="w-12 h-12 mb-4 opacity-20" />
                    <p>Select a file to start editing</p>
                  </div>
                )}
              </ResizablePanel>
              
              <ResizableHandle className="bg-border hover:bg-primary transition-colors h-[2px]" />
              
              {/* Terminal / Output */}
              <ResizablePanel defaultSize={30} minSize={10} className="bg-[#1e1e1e] flex flex-col">
                <div className="h-8 bg-card border-b border-border flex items-center px-4 gap-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-foreground border-b-2 border-primary h-full px-1">
                    <TerminalSquare className="w-3 h-3" /> Console
                  </div>
                  <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground h-full px-1 hover:text-foreground cursor-pointer transition-colors">
                    Shell
                  </div>
                </div>
                <ScrollArea className="flex-1 p-4 font-mono text-sm">
                  {output ? (
                    <pre className="whitespace-pre-wrap text-foreground/90">{output}</pre>
                  ) : (
                    <div className="text-muted-foreground/50 italic">
                      Application output will appear here...
                    </div>
                  )}
                </ScrollArea>
              </ResizablePanel>
              
            </ResizablePanelGroup>
          </ResizablePanel>
          
        </ResizablePanelGroup>
      </div>
    </div>
  );
}
