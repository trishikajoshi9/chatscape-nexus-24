import { Button } from "@/components/ui/button";
import { Terminal, Cpu, Zap, Share2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-white/5 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-xl text-primary">
            <Terminal className="w-6 h-6" />
            TRITEC
          </div>
          <div className="flex gap-4">
            <Button asChild variant="ghost" className="text-muted-foreground hover:text-foreground">
              <a href="/api/login">Sign In</a>
            </Button>
            <Button asChild className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20">
              <a href="/api/login">Get Started</a>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-24 pb-32 overflow-hidden">
        {/* Abstract Background Element */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-primary/10 rounded-full blur-[120px] -z-10" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-white mb-6">
                Code like a pro, <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-500">
                  directly in your browser.
                </span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
                Instant development environments for modern web applications. 
                Zero setup. Real-time collaboration. Powerful AI assistance.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="text-lg px-8 h-14 rounded-xl bg-primary hover:bg-primary/90 shadow-xl shadow-primary/20 hover:scale-105 transition-all duration-200">
                  <a href="/api/login">Start Coding for Free</a>
                </Button>
              </div>
            </motion.div>

            {/* Editor Preview Image */}
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.7 }}
              className="mt-16 relative mx-auto max-w-5xl rounded-xl border border-white/10 shadow-2xl bg-[#1e1e1e] overflow-hidden"
            >
              <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-[#252526]">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                </div>
                <div className="mx-auto text-xs text-muted-foreground font-mono">main.tsx — Tritec</div>
              </div>
              <div className="p-0">
                {/* Simulated Code Editor UI */}
                <div className="flex h-[400px]">
                  <div className="w-64 border-r border-white/5 bg-[#252526] p-4 hidden sm:block">
                    <div className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wider">Explorer</div>
                    <div className="space-y-2 font-mono text-sm text-muted-foreground">
                      <div className="flex items-center gap-2 text-white"><span className="text-blue-400">TSX</span> App.tsx</div>
                      <div className="flex items-center gap-2 pl-4">components/</div>
                      <div className="flex items-center gap-2 pl-4">lib/</div>
                      <div className="flex items-center gap-2">index.css</div>
                    </div>
                  </div>
                  <div className="flex-1 p-6 font-mono text-sm text-left">
                    <div className="text-blue-400">import</div> <span className="text-yellow-300">React</span> <div className="text-blue-400 inline">from</div> <span className="text-green-300">'react'</span>;<br/>
                    <br/>
                    <div className="text-blue-400 inline">function</div> <span className="text-yellow-300">App</span>() {'{'}<br/>
                    &nbsp;&nbsp;<div className="text-blue-400 inline">return</div> (<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-green-300">div</span> className=<span className="text-orange-300">"app"</span>&gt;<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-green-300">h1</span>&gt;Hello World&lt;/<span className="text-green-300">h1</span>&gt;<br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-green-300">div</span>&gt;<br/>
                    &nbsp;&nbsp;);<br/>
                    {'}'}<br/>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Zap className="w-8 h-8 text-yellow-400" />}
              title="Instant Setup"
              description="Spin up a fresh environment in milliseconds. No docker files, no config hell."
            />
            <FeatureCard 
              icon={<Cpu className="w-8 h-8 text-blue-400" />}
              title="Cloud Powered"
              description="Run intensive tasks on our powerful cloud infrastructure. Save your battery."
            />
            <FeatureCard 
              icon={<Share2 className="w-8 h-8 text-green-400" />}
              title="Collaborative"
              description="Code with your team in real-time. Share a link and start pairing instantly."
            />
          </div>
        </div>
      </section>

      <footer className="py-8 border-t border-white/5 text-center text-muted-foreground text-sm">
        <p>&copy; 2024 Tritec. Built for developers.</p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-8 rounded-2xl bg-background border border-white/5 hover:border-primary/50 transition-colors group">
      <div className="mb-4 p-3 rounded-lg bg-card inline-block group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">
        {description}
      </p>
    </div>
  );
}
