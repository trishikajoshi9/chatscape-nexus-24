import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

type File = z.infer<typeof api.files.list.responses[200]>[number];

export function useFiles(projectId: number) {
  return useQuery({
    queryKey: [api.files.list.path, projectId],
    queryFn: async () => {
      const url = buildUrl(api.files.list.path, { projectId });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return [];
      if (!res.ok) throw new Error("Failed to fetch files");
      return api.files.list.responses[200].parse(await res.json());
    },
    enabled: !!projectId,
  });
}

export function useCreateFile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ projectId, name, content }: { projectId: number; name: string; content: string }) => {
      const url = buildUrl(api.files.create.path, { projectId });
      const validated = api.files.create.input.parse({ name, content });
      
      const res = await fetch(url, {
        method: api.files.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.files.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create file");
      }
      return api.files.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      const url = buildUrl(api.files.list.path, { projectId: variables.projectId });
      queryClient.invalidateQueries({ queryKey: [api.files.list.path, variables.projectId] });
    },
  });
}

export function useUpdateFile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, projectId, content }: { id: number; projectId: number; content: string }) => {
      const url = buildUrl(api.files.update.path, { id });
      const validated = api.files.update.input.parse({ content });
      
      const res = await fetch(url, {
        method: api.files.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to update file");
      return api.files.update.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.files.list.path, variables.projectId] });
    },
  });
}

export function useDeleteFile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, projectId }: { id: number; projectId: number }) => {
      const url = buildUrl(api.files.delete.path, { id });
      const res = await fetch(url, { 
        method: api.files.delete.method,
        credentials: "include" 
      });

      if (!res.ok) throw new Error("Failed to delete file");
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.files.list.path, variables.projectId] });
    },
  });
}
